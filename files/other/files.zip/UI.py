from tkinter import *
from tkinter import messagebox
from start import *

root = Tk()
root.title('Server UI')
root.geometry('650x550')
root.resizable(width=False, height=False)
root['bg'] = 'blue'
port = StringVar()
Entry(root, textvariable=port, bg="blue").pack()
def applyport():
    portfile = open('port.cfg.dll', 'w')
    portfile.write(port.get())
def server():
    root.destroy()
    serverUP()
Button(root, bg='blue', text="Apply port", font="Roman 18 bold", command=lambda: applyport()).pack()
Button(root, bg='blue', text="Start Server", font="Roman 18 bold", command=lambda: server()).pack()


root.mainloop()